export const siteConfig = {
  name: 'MERINI Digital Platform',
  title: 'MERINI | Digital Growth Studio',
  description:
    'Creative digital agency helping brands grow through strategy, design, web experiences, and performance marketing.',
  url: 'https://merini-digital.com',
  locale: 'en',
  author: 'MERINI',
  keywords: ['digital agency', 'branding', 'web development', 'seo', 'growth marketing'],
  ogImage: '/og-image.jpg',
};