import { siteConfig } from '@/config/site';

export function getOrganizationStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: siteConfig.name,
    url: siteConfig.url,
    logo: `${siteConfig.url}/logo.png`,
    sameAs: [
      'https://www.linkedin.com',
      'https://www.instagram.com',
      'https://www.facebook.com',
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      contactType: 'customer service',
      areaServed: 'Worldwide',
      availableLanguage: ['English', 'French', 'Arabic', 'Spanish'],
    },
  };
}