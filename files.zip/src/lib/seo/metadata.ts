import type { Metadata } from 'next';
import { siteConfig } from '@/config/site';

type MetaOptions = {
  title?: string;
  description?: string;
  path?: string;
};

export function buildMetadata({
  title = siteConfig.title,
  description = siteConfig.description,
  path = '/',
}: MetaOptions = {}): Metadata {
  const canonical = `${siteConfig.url}${path}`;

  return {
    title,
    description,
    metadataBase: new URL(siteConfig.url),
    alternates: {
      canonical,
    },
    openGraph: {
      title,
      description,
      url: canonical,
      siteName: siteConfig.name,
      type: 'website',
      images: [
        {
          url: siteConfig.ogImage,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [siteConfig.ogImage],
    },
  };
}