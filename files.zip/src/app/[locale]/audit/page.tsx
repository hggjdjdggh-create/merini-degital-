import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'Audit | MERINI',
  description: 'Brand, web, and digital growth audit services.',
  path: '/audit',
});

export default function AuditPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">Digital Audit</h1>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border p-6">
          <h2 className="text-xl font-semibold">Brand Audit</h2>
          <p className="mt-3 text-slate-600">Evaluate positioning, consistency, and conversion potential.</p>
        </div>
        <div className="rounded-xl border p-6">
          <h2 className="text-xl font-semibold">Web Audit</h2>
          <p className="mt-3 text-slate-600">Improve UX, technical performance, and funnel quality.</p>
        </div>
      </div>
    </main>
  );
}