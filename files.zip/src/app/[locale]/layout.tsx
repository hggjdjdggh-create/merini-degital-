import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import '@/app/globals.css';
import { buildMetadata } from '@/lib/seo/metadata';
import { getOrganizationStructuredData } from '@/lib/seo/structured-data';
import { JsonLd } from '@/components/seo/JsonLd';

const locales = ['en', 'fr', 'ar', 'es'];

const inter = Inter({ subsets: ['latin'] });

export async function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export const metadata: Metadata = buildMetadata({
  title: 'MERINI | Digital Strategy Studio',
  description: 'Digital agency for brand, web, SEO, and performance growth.',
  path: '/',
});

export default function RootLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const locale = params.locale;

  return (
    <html lang={locale}>
      <body className={inter.className}>
        <JsonLd data={getOrganizationStructuredData()} />
        {children}
      </body>
    </html>
  );
}