import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'Work | MERINI',
  description: 'Selected projects and outcomes driven by design and performance.',
  path: '/work',
});

export default function WorkPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">Selected Work</h1>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border p-6 shadow-soft">
          <h2 className="text-xl font-semibold">B2B Platform Redesign</h2>
          <p className="mt-3 text-slate-600">Improved conversion and UX for a SaaS platform.</p>
        </div>
        <div className="rounded-xl border p-6 shadow-soft">
          <h2 className="text-xl font-semibold">Luxury Brand Launch</h2>
          <p className="mt-3 text-slate-600">Built a premium digital identity and launch funnel.</p>
        </div>
      </div>
    </main>
  );
}