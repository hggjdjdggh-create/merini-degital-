import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'Contact | MERINI',
  description: 'Contact MERINI for branding, web, and growth projects.',
  path: '/contact',
});

export default function ContactPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">Contact Us</h1>
      <div className="mt-10 rounded-xl border p-8 shadow-soft">
        <p className="text-lg">hello@merini-digital.com</p>
        <p className="mt-3 text-slate-600">Available for projects worldwide.</p>
      </div>
    </main>
  );
}