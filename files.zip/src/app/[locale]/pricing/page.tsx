import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'Pricing | MERINI',
  description: 'Flexible pricing for web, branding, and growth projects.',
  path: '/pricing',
});

export default function PricingPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">Pricing</h1>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        <div className="rounded-xl border p-6 shadow-soft">
          <h2 className="text-xl font-semibold">Starter</h2>
          <p className="mt-4 text-3xl font-bold">$1,500</p>
          <p className="mt-3">Ideal for small businesses and launches.</p>
        </div>
        <div className="rounded-xl border border-orange-500 p-6 shadow-soft">
          <h2 className="text-xl font-semibold">Growth</h2>
          <p className="mt-4 text-3xl font-bold">$4,500</p>
          <p className="mt-3">For scaling brands with stronger needs.</p>
        </div>
        <div className="rounded-xl border p-6 shadow-soft">
          <h2 className="text-xl font-semibold">Custom</h2>
          <p className="mt-4 text-3xl font-bold">Tailored</p>
          <p className="mt-3">For large-scale strategic engagements.</p>
        </div>
      </div>
    </main>
  );
}