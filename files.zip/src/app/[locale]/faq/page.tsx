import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'FAQ | MERINI',
  description: 'Frequently asked questions about our process and engagements.',
  path: '/faq',
});

export default function FaqPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">FAQ</h1>
      <div className="mt-10 space-y-6">
        <div className="rounded-xl border p-6">
          <h2 className="text-lg font-semibold">How long does a project take?</h2>
          <p className="mt-2 text-slate-600">Most projects take between 3 and 8 weeks based on scope.</p>
        </div>
        <div className="rounded-xl border p-6">
          <h2 className="text-lg font-semibold">Do you work internationally?</h2>
          <p className="mt-2 text-slate-600">Yes, our team supports clients worldwide.</p>
        </div>
      </div>
    </main>
  );
}