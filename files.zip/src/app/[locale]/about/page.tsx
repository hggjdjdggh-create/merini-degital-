import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'About | MERINI',
  description: 'Learn more about MERINI and the team behind the work.',
  path: '/about',
});

export default function AboutPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">About MERINI</h1>
      <p className="mt-6 max-w-3xl text-lg text-slate-600">
        MERINI is a digital growth studio helping ambitious businesses clarify their message,
        elevate their presence, and convert attention into measurable outcomes.
      </p>
    </main>
  );
}