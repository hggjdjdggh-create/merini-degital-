import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'MERINI | Home',
  description: 'Brand, product, web and marketing experiences for ambitious businesses.',
  path: '/',
});

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <section className="mx-auto max-w-6xl px-6 py-24">
        <p className="mb-4 text-sm uppercase tracking-[0.2em] text-orange-400">
          MERINI Digital Platform
        </p>
        <h1 className="max-w-3xl text-5xl font-bold leading-tight">
          Digital experiences that turn attention into growth.
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-slate-300">
          Strategy, branding, design, web performance, and growth systems for modern businesses.
        </p>
        <div className="mt-10 flex gap-4">
          <a href="/en/services" className="rounded-lg bg-orange-500 px-6 py-3 font-medium text-white">
            Explore Services
          </a>
          <a href="/en/contact" className="rounded-lg border border-slate-700 px-6 py-3 font-medium text-white">
            Talk to Us
          </a>
        </div>
      </section>
    </main>
  );
}