import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'Process | MERINI',
  description: 'How we work from discovery to execution and measurement.',
  path: '/process',
});

export default function ProcessPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">Our Process</h1>
      <div className="mt-10 grid gap-6 md:grid-cols-4">
        <div className="rounded-xl border p-6 shadow-soft"><strong>01</strong><p className="mt-3">Discovery</p></div>
        <div className="rounded-xl border p-6 shadow-soft"><strong>02</strong><p className="mt-3">Strategy</p></div>
        <div className="rounded-xl border p-6 shadow-soft"><strong>03</strong><p className="mt-3">Design & Build</p></div>
        <div className="rounded-xl border p-6 shadow-soft"><strong>04</strong><p className="mt-3">Measure & Improve</p></div>
      </div>
    </main>
  );
}