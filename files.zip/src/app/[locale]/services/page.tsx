import { buildMetadata } from '@/lib/seo/metadata';

export const metadata = buildMetadata({
  title: 'Services | MERINI',
  description: 'Brand strategy, UI/UX, web design, and growth marketing services.',
  path: '/services',
});

export default function ServicesPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-24 text-slate-900">
      <h1 className="text-4xl font-bold">Our Services</h1>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        <div className="rounded-xl border p-6 shadow-soft">
          <h2 className="text-xl font-semibold">Brand Strategy</h2>
          <p className="mt-3 text-slate-600">Positioning, messaging, and creative systems.</p>
        </div>
        <div className="rounded-xl border p-6 shadow-soft">
          <h2 className="text-xl font-semibold">Web Experience</h2>
          <p className="mt-3 text-slate-600">High-converting websites and product experiences.</p>
        </div>
        <div className="rounded-xl border p-6 shadow-soft">
          <h2 className="text-xl font-semibold">Growth Marketing</h2>
          <p className="mt-3 text-slate-600">Paid acquisition, SEO, and lifecycle optimization.</p>
        </div>
      </div>
    </main>
  );
}